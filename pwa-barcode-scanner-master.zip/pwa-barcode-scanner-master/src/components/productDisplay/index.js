import ProductDisplay from './ProductDisplay';

export default ProductDisplay;
