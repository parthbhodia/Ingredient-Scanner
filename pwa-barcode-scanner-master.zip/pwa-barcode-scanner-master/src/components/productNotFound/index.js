import ProductNotFound from './productNotFound';

export default ProductNotFound;
