import DataHandler from './DataHandler';

export default DataHandler;
