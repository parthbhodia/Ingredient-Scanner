import NutriScore from './nutriScore';

export default NutriScore;
