import AddProductInfo from './AddProductInfo';

export default AddProductInfo;
