
Contributing to pwa-barcode-scanner

    Fork this repository to your own GitHub account and then clone it to your local device.
    Install the dependencies: npm install
    Run npm run dev to watch changes from /src
    Open a PR with your changes :)
    Each PR will create a netlify staging url
    Have fun!
